jQuery(document).ready(function() {
    jQuery('#hq-d-date, #hq-c-date').datepicker({
        dateFormat : 'dd-mm-yy'
    });
});